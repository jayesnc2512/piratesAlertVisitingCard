import React from 'react';
import './pastInfringement.css';

const SellerCard = () => {

    return (
        <div className='row   seller-card'>
            <div className='col-9 '>
                Username
            </div>
            <div className='col-3 '>
                xyz
            </div>
            <div className='col-9 '>
                Platform
            </div>
            <div className='col-3 '>
                xyz
            </div>
        </div>
    )
}

export default SellerCard